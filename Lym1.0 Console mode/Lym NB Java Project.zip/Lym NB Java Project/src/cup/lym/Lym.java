package cup.lym;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Lym class for the execution of the lexer (scanner) and parser.
 * @author LuisMolina
 * @author Michelle Alvarado
 */
public class Lym {
	private BufferedReader reader;			 	// For user inputs
	private String path = ""; 				 	// For save the inserted path
	private LymParser parser = null; 			// The LymParser
	private LymScanner scanner = null;			// The LymSpanner
	
	/**
	 * Main method for execution
	 * @param args
	 */
	public static void main(String[] args) {
		Lym lymApl = new Lym();
		lymApl.run();
	}
	
	/**
	 * Lym application constructor
	 */
	public Lym() {
		reader = new BufferedReader(new InputStreamReader(System.in));
	}
	
	/**
	 * It executes the Lym console application
	 */
	public void run() {
		boolean quit = setFilepath();
		if (!quit) showMenu();
	}
	
	/**
	 * Asks for the file path of the source code
	 * @return boolean, true if the user decides to exit, false if it wants to continue
	 */
	private boolean setFilepath() {
		boolean good = true;
		boolean quit = false;
		do {
			System.out.println("==== Lym Scanner-Parser ====");
			if (!good) System.out.print("The filepath is incorrect. Please, type the file path for scan or parse (type 'exit' to exit): ");
			else System.out.print("Please, type the file path for scan or parse (type 'exit' to exit): ");
			try {
				path = reader.readLine();
				if (path.equals("exit")) return true;
				File file = new File(path);
				FileInputStream fileInput = new FileInputStream(file);
			    quit = false;
			    return quit;
			} catch (IOException e) {
				good = false;
			}
		} while(!quit);
		return quit;
	}
	
	/**
	 * Show a menu with options to scan or parse the source file.
	 */
	private void showMenu() {
		boolean quit = false;
		int option = -1;
		try {
			do {
				System.out.println("==== Lym Scanner-Parser ====");
				System.out.println("Path: " + path);
				System.out.println("1. Run Scanner: Generates tokens file and checks for lexical errors.");
				System.out.println("2. Run Parser: Uses Scanner services for tokens information and checks the Lym language Grammar.");
				System.out.println("\tThis will report the grammar errors.");
				System.out.println("3. Change file path.");
				System.out.println("4. Exit.");
				if(option == 0) System.out.print("Select a valid option: ");
				else System.out.print("Select an option: ");
				try {
					option = Integer.parseInt(reader.readLine());
				} catch (NumberFormatException e) {
					option = 0;
				}
				switch(option) {
					case 1:
						executeScanner();
						break;
					case 2:
						executeParser();
						break;
					case 3:
						quit = setFilepath();
						break;
					case 4:
						quit = true;
						break;
					default:
						option = 0;
						break;
				}
			} while(!quit);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Creates a new LymLexer instance
	 * @return LymScanner object if there is no exceptions, false otherwise
	 */
	private LymScanner createScanner() {
		try {
			File file = new File(path);
			FileInputStream fileInput = new FileInputStream(file);
			return new LymScanner(fileInput, file);
		} catch (FileNotFoundException e) {
			return null;
		}
	}
	
	/**
	 * It executes the scanner, the scanner generates the tokens file an print them in console.
	 */
	private void executeScanner() {
		this.scanner = this.createScanner();
		if (scanner != null) {
			try {
				System.out.println("\n");
				this.scanner.execute();
				System.out.println("\n");
				System.out.print("Press any key to continue...");
				reader.readLine();
			} catch (IOException e) {
				System.out.println("Error executing scanner. " + e.toString());
			}
		} else {
			System.out.println("Error creating scanner, check file.");
		}
	}
	
	/**
	 * It executes the parser, the parser generates an errors file and print them in console, it also says if the file can be generated
	 * by the grammar.
	 */
	private void executeParser() {
		this.scanner = this.createScanner();
		if (scanner != null) {
			this.parser = new LymParser(this.scanner);
			try {
				System.out.println("\n");
				this.parser.execute();
				System.out.println("\n");
				System.out.print("Press any key to continue...");
				reader.readLine();
			} catch (Exception e) {
				System.out.println("Error executing parser. " + e.toString());
				e.printStackTrace();
			}
		} else {
			System.out.println("Error creating scanner, check file.");
		}
	}
}
